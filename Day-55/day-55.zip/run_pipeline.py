from etl.extract import extract_data
from etl.validate import validate_data
from etl.clean import clean_data
from etl.transform import transform_data
from etl.load import load_to_postgres


def main():
    orders, customers, products, sellers, payments = extract_data()

    issues = validate_data(orders, customers, products, sellers, payments)
    print("Validation issues:", issues)

    orders, customers, products, sellers, payments = clean_data(
        orders, customers, products, sellers, payments
    )
    fact_orders, dim_customers, dim_products, dim_sellers = transform_data(
        orders, customers, products, sellers, payments
    )

    print("Fact Orders:", fact_orders.shape)
    print("Dim Customers:", dim_customers.shape)
    print("Dim Products:", dim_products.shape)
    print("Dim Sellers:", dim_sellers.shape)

    load_to_postgres()


if __name__ == "__main__":
    main()
