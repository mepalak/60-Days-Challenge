import os
import pandas as pd
from sqlalchemy import create_engine
from dotenv import load_dotenv

from etl.extract import extract_data
from etl.clean import clean_data
from etl.transform import transform_data

DATE_COLUMNS = [
    "order_purchase_timestamp",
    "order_approved_at",
    "order_delivered_carrier_date",
    "order_delivered_customer_date",
    "order_estimated_delivery_date",
]


def load_to_postgres():
    load_dotenv()
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise ValueError("DATABASE_URL not found in .env file")

    engine = create_engine(db_url)

    orders, customers, products, sellers, payments = extract_data()
    orders, customers, products, sellers, payments = clean_data(
        orders, customers, products, sellers, payments
    )
    fact_orders, dim_customers, dim_products, dim_sellers = transform_data(
        orders, customers, products, sellers, payments
    )

    # Convert date-like string columns to real datetimes so Postgres TIMESTAMP
    # columns receive proper values instead of raw strings.
    for col in DATE_COLUMNS:
        fact_orders[col] = pd.to_datetime(fact_orders[col], errors="coerce")

    # Load dimension tables first (fact_orders has FK -> dim_customers)
    dim_customers.to_sql("dim_customers", engine, if_exists="append", index=False)
    dim_products.to_sql("dim_products", engine, if_exists="append", index=False)
    dim_sellers.to_sql("dim_sellers", engine, if_exists="append", index=False)
    fact_orders.to_sql("fact_orders", engine, if_exists="append", index=False)

    print("Data successfully loaded into Neon PostgreSQL!")
    print(f"  dim_customers: {len(dim_customers)} rows")
    print(f"  dim_products:  {len(dim_products)} rows")
    print(f"  dim_sellers:   {len(dim_sellers)} rows")
    print(f"  fact_orders:   {len(fact_orders)} rows")


if __name__ == "__main__":
    load_to_postgres()
