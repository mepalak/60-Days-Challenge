DROP TABLE IF EXISTS fact_orders CASCADE;
DROP TABLE IF EXISTS dim_customers CASCADE;
DROP TABLE IF EXISTS dim_products CASCADE;
DROP TABLE IF EXISTS dim_sellers CASCADE;

CREATE TABLE dim_customers (
    customer_id             VARCHAR(64) PRIMARY KEY,
    customer_unique_id      VARCHAR(64),
    customer_zip_code_prefix VARCHAR(16),
    customer_city           VARCHAR(128),
    customer_state          VARCHAR(8)
);

CREATE TABLE dim_products (
    product_id                 VARCHAR(64) PRIMARY KEY,
    product_category_name      VARCHAR(128),
    product_name_length        NUMERIC,
    product_description_length NUMERIC,
    product_photos_qty         NUMERIC,
    product_weight_g           NUMERIC,
    product_length_cm          NUMERIC,
    product_height_cm          NUMERIC,
    product_width_cm           NUMERIC
);

CREATE TABLE dim_sellers (
    seller_id               VARCHAR(64) PRIMARY KEY,
    seller_zip_code_prefix  VARCHAR(16),
    seller_city             VARCHAR(128),
    seller_state            VARCHAR(8)
);

CREATE TABLE fact_orders (
    order_id                        VARCHAR(64) PRIMARY KEY,
    customer_id                     VARCHAR(64) REFERENCES dim_customers(customer_id),
    order_status                    VARCHAR(32),
    order_purchase_timestamp        TIMESTAMP,
    order_approved_at               TIMESTAMP,
    order_delivered_carrier_date    TIMESTAMP,
    order_delivered_customer_date   TIMESTAMP,
    order_estimated_delivery_date   TIMESTAMP,
    payment_value                   NUMERIC
);

CREATE INDEX idx_fact_orders_customer_id ON fact_orders(customer_id);
CREATE INDEX idx_fact_orders_purchase_ts ON fact_orders(order_purchase_timestamp);
