## Day 5 — Data Warehouse Loading

### Setup
1. Create a free Neon account at https://neon.tech
2. Create a project, copy the connection string, and save it in `.env`:
   ```
   DATABASE_URL=postgresql://user:password@host/dbname?sslmode=require
   ```
3. Run schema creation (once) using the Neon SQL Editor — paste and run
   the contents of `etl/schema.sql`.

### Run Pipeline
```bash
python run_pipeline.py
```

### Verify
```sql
SELECT COUNT(*) FROM fact_orders;
SELECT COUNT(*) FROM dim_customers;
SELECT COUNT(*) FROM dim_products;
SELECT COUNT(*) FROM dim_sellers;

SELECT o.order_id, c.customer_city, o.payment_value
FROM fact_orders o
JOIN dim_customers c ON o.customer_id = c.customer_id
LIMIT 10;
```

### Verified Results (Day 5)
- fact_orders: 99,441 rows
- dim_customers: 99,441 rows
- dim_products: 32,951 rows
- dim_sellers: 3,095 rows
- Sample join returned correct city/payment data with no nulls.

### Notes
- Date columns (`order_purchase_timestamp`, etc.) are explicitly converted
  to `datetime64` in `load.py` before insert, since pandas reads CSV dates
  as plain strings by default.
- `load.py` uses `if_exists="append"`, not `"replace"`, so the primary
  keys, foreign keys, and indexes defined in `schema.sql` are preserved.
  Re-running `run_pipeline.py` on a non-empty database will fail on
  duplicate primary keys — truncate the tables first if you need to reload.
