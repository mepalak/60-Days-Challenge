import pandas as pd

def extract_orders():
    return pd.read_csv("data/olist_orders_dataset.csv")

def extract_customers():
    return pd.read_csv("data/olist_customers_dataset.csv")

def extract_products():
    return pd.read_csv("data/olist_products_dataset.csv")

def extract_sellers():
    return pd.read_csv("data/olist_sellers_dataset.csv")

def extract_order_items():
    return pd.read_csv("data/olist_order_items_dataset.csv")

if __name__ == "__main__":
    print("Extracting datasets...")
    orders = extract_orders()
    customers = extract_customers()
    products = extract_products()
    sellers = extract_sellers()
    order_items = extract_order_items()
    print(
        "Orders:", orders.shape,
        "Customers:", customers.shape,
        "Products:", products.shape,
        "Sellers:", sellers.shape,
        "Order Items:", order_items.shape,
    )
