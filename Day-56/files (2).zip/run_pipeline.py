from etl.extract import (
    extract_orders,
    extract_customers,
    extract_products,
    extract_sellers,
    extract_order_items,
)
from etl.validate import validate
from etl.clean import (
    clean_orders,
    clean_customers,
    clean_products,
    clean_sellers,
    clean_order_items,
)
from etl.transform import (
    build_fact_orders,
    build_dim_customers,
    build_dim_products,
    build_dim_sellers,
)
from db.load import load_to_postgres

def run_pipeline():
    print("Running ETL pipeline...")

    orders = extract_orders()
    customers = extract_customers()
    products = extract_products()
    sellers = extract_sellers()
    order_items = extract_order_items()

    validate(orders, "orders")
    validate(customers, "customers")
    validate(products, "products")
    validate(sellers, "sellers")
    validate(order_items, "order_items")

    orders = clean_orders(orders)
    customers = clean_customers(customers)
    products = clean_products(products)
    sellers = clean_sellers(sellers)
    order_items = clean_order_items(order_items)

    # transform.py reads these back from disk, so they must be saved first
    orders.to_csv("data/clean_orders.csv", index=False)
    customers.to_csv("data/clean_customers.csv", index=False)
    products.to_csv("data/clean_products.csv", index=False)
    sellers.to_csv("data/clean_sellers.csv", index=False)
    order_items.to_csv("data/clean_order_items.csv", index=False)

    fact_orders = build_fact_orders()
    dim_customers = build_dim_customers()
    dim_products = build_dim_products()
    dim_sellers = build_dim_sellers()

    fact_orders.to_csv("data/fact_orders.csv", index=False)
    dim_customers.to_csv("data/dim_customers.csv", index=False)
    dim_products.to_csv("data/dim_products.csv", index=False)
    dim_sellers.to_csv("data/dim_sellers.csv", index=False)

    load_to_postgres(truncate=True)
    print("Pipeline complete.")

if __name__ == "__main__":
    run_pipeline()
