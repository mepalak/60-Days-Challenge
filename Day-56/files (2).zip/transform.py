import pandas as pd

def build_fact_orders():
    orders = pd.read_csv("data/clean_orders.csv")
    order_items = pd.read_csv("data/clean_order_items.csv")

    # An order can have multiple line items (multiple products/sellers).
    # fact_orders has one row per order_id (matches schema.sql PRIMARY KEY),
    # so we take the first item per order as the representative product/seller.
    # This is a simplification: line-item-level detail is not preserved here.
    first_item = (
        order_items.sort_values("order_item_id")
        .groupby("order_id", as_index=False)
        .first()[["order_id", "product_id", "seller_id"]]
    )

    merged = orders.merge(first_item, on="order_id", how="left")

    return merged[
        [
            "order_id",
            "customer_id",
            "product_id",
            "seller_id",
            "order_status",
            "order_purchase_timestamp",
        ]
    ]

def build_dim_customers():
    customers = pd.read_csv("data/clean_customers.csv")
    return customers[["customer_id", "customer_unique_id", "customer_city", "customer_state"]]

def build_dim_products():
    products = pd.read_csv("data/clean_products.csv")
    return products[["product_id", "product_category_name"]]

def build_dim_sellers():
    sellers = pd.read_csv("data/clean_sellers.csv")
    return sellers[["seller_id", "seller_city", "seller_state"]]

if __name__ == "__main__":
    fact_orders = build_fact_orders()
    dim_customers = build_dim_customers()
    dim_products = build_dim_products()
    dim_sellers = build_dim_sellers()

    fact_orders.to_csv("data/fact_orders.csv", index=False)
    dim_customers.to_csv("data/dim_customers.csv", index=False)
    dim_products.to_csv("data/dim_products.csv", index=False)
    dim_sellers.to_csv("data/dim_sellers.csv", index=False)
    print("Star schema tables created.")
