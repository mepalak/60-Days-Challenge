import os
import pandas as pd
from etl.extract import (
    extract_orders,
    extract_customers,
    extract_products,
    extract_sellers,
    extract_order_items,
)

os.makedirs("data", exist_ok=True)

def clean_orders(df):
    return df.dropna(subset=["order_id", "customer_id"])

def clean_customers(df):
    return df.dropna(subset=["customer_id"])

def clean_products(df):
    return df.dropna(subset=["product_id"])

def clean_sellers(df):
    return df.dropna(subset=["seller_id"])

def clean_order_items(df):
    return df.dropna(subset=["order_id", "product_id", "seller_id"])

if __name__ == "__main__":
    orders = clean_orders(extract_orders())
    customers = clean_customers(extract_customers())
    products = clean_products(extract_products())
    sellers = clean_sellers(extract_sellers())
    order_items = clean_order_items(extract_order_items())

    orders.to_csv("data/clean_orders.csv", index=False)
    customers.to_csv("data/clean_customers.csv", index=False)
    products.to_csv("data/clean_products.csv", index=False)
    sellers.to_csv("data/clean_sellers.csv", index=False)
    order_items.to_csv("data/clean_order_items.csv", index=False)
    print("Cleaned datasets saved.")
