import os
import pandas as pd
from sqlalchemy import create_engine, text

def load_to_postgres(truncate=False):
    db_url = (
        f"postgresql+psycopg2://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}"
        f"@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT', 5432)}/{os.getenv('DB_NAME')}"
    )
    engine = create_engine(db_url)
    try:
        if truncate:
            with engine.begin() as conn:
                conn.execute(text(
                    "TRUNCATE TABLE fact_orders, dim_customers, dim_products, dim_sellers "
                    "RESTART IDENTITY CASCADE;"
                ))

        print("Loading dim_customers...")
        pd.read_csv("data/dim_customers.csv").to_sql("dim_customers", engine, if_exists="append", index=False)
        print("Loading dim_products...")
        pd.read_csv("data/dim_products.csv").to_sql("dim_products", engine, if_exists="append", index=False)
        print("Loading dim_sellers...")
        pd.read_csv("data/dim_sellers.csv").to_sql("dim_sellers", engine, if_exists="append", index=False)
        print("Loading fact_orders...")
        pd.read_csv("data/fact_orders.csv").to_sql("fact_orders", engine, if_exists="append", index=False)
        print("All tables loaded successfully.")
    finally:
        engine.dispose()

if __name__ == "__main__":
    load_to_postgres(truncate=True)
