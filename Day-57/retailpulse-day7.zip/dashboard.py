import streamlit as st
import pandas as pd
from datetime import date, timedelta
from sqlalchemy import create_engine, text

# ----------------------------------------------------------------------------
# Page config
# ----------------------------------------------------------------------------
st.set_page_config(page_title="RetailPulse Dashboard", page_icon="📊", layout="wide")

# ----------------------------------------------------------------------------
# Database connection
# ----------------------------------------------------------------------------
if "DB_URI" not in st.secrets:
    st.error(
        "Database connection is not configured. "
        "Add a `DB_URI` value in your Streamlit secrets (Settings → Secrets)."
    )
    st.stop()

DB_URI = st.secrets["DB_URI"]


@st.cache_resource
def get_engine():
    return create_engine(DB_URI, pool_pre_ping=True)


engine = get_engine()

# ----------------------------------------------------------------------------
# Data loading (parameterized, cached per query+params combination)
# ----------------------------------------------------------------------------
@st.cache_data(ttl=600, show_spinner=False)
def load_data(query: str, params: dict | None = None) -> pd.DataFrame:
    try:
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn, params=params or {})
    except Exception as e:
        st.session_state["last_db_error"] = str(e)
        return pd.DataFrame()


@st.cache_data(ttl=600, show_spinner=False)
def get_date_bounds() -> tuple[date, date]:
    query = "SELECT MIN(order_purchase_timestamp)::date AS min_d, MAX(order_purchase_timestamp)::date AS max_d FROM fact_orders;"
    df = load_data(query)
    if df.empty or pd.isna(df.loc[0, "min_d"]):
        today = date.today()
        return today - timedelta(days=30), today
    return df.loc[0, "min_d"], df.loc[0, "max_d"]


# ----------------------------------------------------------------------------
# Header
# ----------------------------------------------------------------------------
st.title("📊 RetailPulse Analytics Dashboard")
st.caption("End-to-end e-commerce pipeline insights — revenue, categories, and payment behavior")

# ----------------------------------------------------------------------------
# Sidebar filters
# ----------------------------------------------------------------------------
st.sidebar.header("Filters")

min_date, max_date = get_date_bounds()

date_range = st.sidebar.date_input(
    "Order date range",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date,
    help="Filters every chart and metric below to orders placed in this window.",
)

# Normalize date_input output: it can return a single date while the user
# is mid-selection, so we guard against that instead of crashing.
if isinstance(date_range, tuple) and len(date_range) == 2:
    start_date, end_date = date_range
else:
    start_date, end_date = min_date, max_date

if start_date > end_date:
    st.sidebar.error("Start date must be before end date. Showing full range instead.")
    start_date, end_date = min_date, max_date

st.sidebar.caption(f"Showing orders from **{start_date}** to **{end_date}**")

date_params = {"start_date": start_date, "end_date": end_date}

# ----------------------------------------------------------------------------
# Queries (all filtered by the selected date range)
# ----------------------------------------------------------------------------
QUERIES = {
    "kpi_revenue": """
        SELECT COALESCE(SUM(payments.payment_value), 0) AS total_revenue
        FROM fact_orders
        JOIN payments ON fact_orders.order_id = payments.order_id
        WHERE fact_orders.order_purchase_timestamp::date BETWEEN :start_date AND :end_date;
    """,
    "revenue_trend": """
        SELECT fact_orders.order_purchase_timestamp::date AS date,
               SUM(payments.payment_value) AS revenue
        FROM fact_orders
        JOIN payments ON fact_orders.order_id = payments.order_id
        WHERE fact_orders.order_purchase_timestamp::date BETWEEN :start_date AND :end_date
        GROUP BY date
        ORDER BY date;
    """,
    "top_categories": """
        SELECT products.product_category_name,
               SUM(payments.payment_value) AS revenue
        FROM fact_orders
        JOIN products ON fact_orders.product_id = products.product_id
        JOIN payments ON fact_orders.order_id = payments.order_id
        WHERE fact_orders.order_purchase_timestamp::date BETWEEN :start_date AND :end_date
        GROUP BY products.product_category_name
        ORDER BY revenue DESC
        LIMIT 10;
    """,
    "payment_mix": """
        SELECT payments.payment_type,
               COUNT(*) AS count
        FROM fact_orders
        JOIN payments ON fact_orders.order_id = payments.order_id
        WHERE fact_orders.order_purchase_timestamp::date BETWEEN :start_date AND :end_date
        GROUP BY payments.payment_type
        ORDER BY count DESC;
    """,
    "orders_table": """
        SELECT fact_orders.order_id,
               fact_orders.order_purchase_timestamp::date AS order_date,
               products.product_category_name,
               payments.payment_type,
               payments.payment_value
        FROM fact_orders
        JOIN products ON fact_orders.product_id = products.product_id
        JOIN payments ON fact_orders.order_id = payments.order_id
        WHERE fact_orders.order_purchase_timestamp::date BETWEEN :start_date AND :end_date
        ORDER BY fact_orders.order_purchase_timestamp DESC
        LIMIT 500;
    """,
}

# ----------------------------------------------------------------------------
# Load all data up front so we can show one clear error if the DB is down
# ----------------------------------------------------------------------------
df_kpi = load_data(QUERIES["kpi_revenue"], date_params)
df_revenue = load_data(QUERIES["revenue_trend"], date_params)
df_categories = load_data(QUERIES["top_categories"], date_params)
df_payment = load_data(QUERIES["payment_mix"], date_params)
df_orders = load_data(QUERIES["orders_table"], date_params)

if "last_db_error" in st.session_state:
    st.error(
        "Could not connect to the database. Check that `DB_URI` in your secrets is correct "
        "and that the database is reachable.\n\n"
        f"Details: {st.session_state['last_db_error']}"
    )
    st.stop()

# ----------------------------------------------------------------------------
# KPI row
# ----------------------------------------------------------------------------
total_revenue = 0.0
if not df_kpi.empty and pd.notna(df_kpi.loc[0, "total_revenue"]):
    total_revenue = float(df_kpi.loc[0, "total_revenue"])

kpi_col, _ = st.columns([1, 3])
with kpi_col:
    st.metric(label="Total Revenue", value=f"${total_revenue:,.2f}")

st.divider()

# ----------------------------------------------------------------------------
# Charts row: revenue trend (line) + payment mix (bar)
# ----------------------------------------------------------------------------
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("Revenue Trend")
    if df_revenue.empty:
        st.info("No revenue data available for the selected date range.")
    else:
        st.line_chart(df_revenue.set_index("date"))

with col2:
    st.subheader("Payment Method Mix")
    if df_payment.empty:
        st.info("No payment data available for the selected date range.")
    else:
        st.bar_chart(df_payment.set_index("payment_type"))

# ----------------------------------------------------------------------------
# Top categories (bar)
# ----------------------------------------------------------------------------
st.subheader("Top Categories by Revenue")
if df_categories.empty:
    st.info("No category data available for the selected date range.")
else:
    st.bar_chart(df_categories.set_index("product_category_name"))

# ----------------------------------------------------------------------------
# Orders table
# ----------------------------------------------------------------------------
st.subheader("Recent Orders")
st.caption("Most recent 500 orders in the selected date range.")
if df_orders.empty:
    st.info("No orders found for the selected date range.")
else:
    st.dataframe(df_orders, use_container_width=True, hide_index=True)
