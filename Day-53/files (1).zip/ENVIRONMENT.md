# ENVIRONMENT.md

## Environment Variables, Tools & Configuration

### Required Environment Variables (`.env`)
```env
# App
NODE_ENV=development
PORT=3000
APP_NAME=my-project

# API
API_BASE_URL=http://localhost:4000/api
API_KEY=your_api_key_here

# Database (if applicable)
DATABASE_URL=postgres://user:password@localhost:5432/dbname

# Auth
JWT_SECRET=your_jwt_secret_here
SESSION_SECRET=your_session_secret_here

# Third-party services
SENTRY_DSN=
ANALYTICS_ID=
```

> ⚠️ Never commit `.env` to version control. It is included in `.gitignore` by default.

### Tooling Overview
| Tool | Purpose | Version |
|---|---|---|
| Node.js | Runtime | v18+ |
| npm | Package manager | v9+ |
| Git | Version control | latest |
| ESLint | Linting | project-configured |
| Prettier | Code formatting | project-configured |
| Jest / Vitest | Testing | project-configured |
| Vite / Webpack | Build tool | project-configured |

### Editor Configuration
- Recommended: VS Code
- Suggested extensions: ESLint, Prettier, GitLens, DotENV

### CI/CD Configuration
- Environment variables for CI/CD should be set in GitHub Actions **Secrets**, not committed to the repo.
- Path: `Repo → Settings → Secrets and variables → Actions`

### Environment Modes
| Mode | File | Purpose |
|---|---|---|
| Development | `.env.development` | Local dev work |
| Staging | `.env.staging` | Pre-production testing |
| Production | `.env.production` | Live deployment |
