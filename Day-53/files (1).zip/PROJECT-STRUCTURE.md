# PROJECT-STRUCTURE.md

## Folder Layout

```
project-root/
├── .github/
│   └── workflows/           # CI/CD pipeline configs
├── docs/
│   ├── SETUP.md
│   ├── PROJECT-STRUCTURE.md
│   ├── ENVIRONMENT.md
│   └── DAY3-SUMMARY.md
├── public/
│   ├── assets/               # Static images, icons, fonts
│   └── index.html
├── src/
│   ├── components/           # Reusable UI components
│   ├── pages/                # Page-level components/routes
│   ├── hooks/                # Custom React hooks
│   ├── services/             # API calls, external integrations
│   ├── store/                # State management (Redux/Zustand/Context)
│   ├── utils/                # Helper functions
│   ├── styles/                # Global styles, themes
│   ├── config/                # App configuration
│   ├── App.jsx
│   └── main.jsx
├── tests/
│   ├── unit/
│   └── integration/
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── vite.config.js (or webpack.config.js)
```

### Key Notes
- **`src/components`** — small, reusable, presentation-focused components.
- **`src/pages`** — route-level views composed of components.
- **`src/services`** — isolates API/network logic from UI logic.
- **`tests/`** — mirrors `src/` structure for easy test discovery.
- **`docs/`** — all project documentation lives here for single-source-of-truth.
