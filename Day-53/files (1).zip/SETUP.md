# SETUP.md

## Project Setup & Installation Guide

### Prerequisites
- Node.js (v18 or later)
- npm (v9+) or yarn
- Git
- A code editor (VS Code recommended)
- GitHub account with SSH or HTTPS access configured

### 1. Clone the Repository
```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment Variables
Copy the example environment file and fill in your values:
```bash
cp .env.example .env
```
See `ENVIRONMENT.md` for full details on required variables.

### 4. Run the Development Server
```bash
npm run dev
```
The app should now be running at `http://localhost:3000`.

### 5. Run Tests
```bash
npm test
```

### 6. Build for Production
```bash
npm run build
```

### 7. Verify Setup
- [ ] Dependencies installed without errors
- [ ] `.env` file configured
- [ ] Dev server starts successfully
- [ ] App loads in browser
- [ ] No console errors

### Troubleshooting
| Issue | Solution |
|---|---|
| `npm install` fails | Delete `node_modules` and `package-lock.json`, retry |
| Port already in use | Change `PORT` in `.env` or kill process on port 3000 |
| Environment variables not loading | Ensure `.env` is in project root and restart dev server |
